﻿using System;
using System.ComponentModel.DataAnnotations;
using CreditoBancario.Helpers;

namespace CreditoBancario.Request
{
    public class ParametrosCreditoRequest : IValidatableObject
    {
        [Required(ErrorMessage = "O campo de valor de crédito é obrigatório.")]
        [Range(1, 1000000, ErrorMessage = "O campo de valor de crédito deve estar entre R$1,00 e R$1.000.000,00 ")]
        public decimal ValorCredito { get; set; }
        [Required(ErrorMessage = "O campo Tipo Credito é obrigatório.")]
        [Range(1, 5, ErrorMessage = "O tipo credito deve ser (1) Credito Direto, (2) Credito Consignado, (3) credito Pessoa Juridica, (4) Credito Pessoa Fisica, (5) Credito Imobiliario.")]
        public int TipoCredito { get; set; }
        [Range(5, 72, ErrorMessage = "A quantidade minima de parcela deve ser 5 e maxima deve ser 72.")]
        public int QuantidadeParcelas { get; set; }
        [Required(ErrorMessage = "O campo Data Primeiro Vencimento é obrigatório.")]
        [ValidaData(ErrorMessage = "A data do primeiro vencimento deve ser entre 15 e 40 dias a partir da data atual.")]
        public DateTime DataPrimeiroVencimento { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (TipoCredito == 3 && ValorCredito < 15000)
            {
                yield return new ValidationResult("O valor mínimo para credito pessoa jurídica é de R$15.000,00 ");
            }
        }

    }
}

