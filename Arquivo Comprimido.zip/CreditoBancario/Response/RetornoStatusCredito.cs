﻿using System;
namespace CreditoBancario.Response
{
    public class RetornoStatusCredito
    {
        public string? statusCredito { get; set; }
        public decimal valorTotalComJuros { get; set; }
        public decimal valorDoJuros { get; set; }
    }
}

