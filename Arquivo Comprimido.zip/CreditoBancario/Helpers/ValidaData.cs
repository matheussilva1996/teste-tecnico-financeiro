﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CreditoBancario.Helpers
{
    public class ValidaData : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime firstDueDate = (DateTime)value;
            DateTime currentDate = DateTime.Now.Date;
            DateTime minDueDate = currentDate.AddDays(15);
            DateTime maxDueDate = currentDate.AddDays(40);

            if (firstDueDate < minDueDate || firstDueDate > maxDueDate)
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }
}

