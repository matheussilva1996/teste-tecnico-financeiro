﻿using System;
using CreditoBancario.Request;
using CreditoBancario.Response;
using CreditoBancario.Utilities;

namespace CreditoBancario.Service
{
	public class CalculoEmprestimo
	{
        public static RetornoStatusCredito CalculoEmprestimoJuros(ParametrosCreditoRequest parametros)
        {

            RetornoStatusCredito retorno = new RetornoStatusCredito();
            decimal taxaJuros;

            switch (parametros.TipoCredito)
            {
                case 1:
                    taxaJuros = TaxaCredito.CREDITO_DIRETO/100;
                    break;
                case 2:
                    taxaJuros = TaxaCredito.CREDITO_CONSIGNADO/100;
                    break;
                case 3:
                    taxaJuros = TaxaCredito.CREDITO_PESSOA_JURIDICA/100;
                    break;
                case 4:
                    taxaJuros = TaxaCredito.CREDITO_PESSOA_FISICA/100;
                    break;
                case 5:
                   
                    taxaJuros = new decimal(Math.Pow(1 + (double)(TaxaCredito.CREDITO_IMOBILIARIO / 100), 1.0 / 12) - 1);
                    break;
                default:
                    throw new ArgumentException("Tipo de crédito inválido");
            }

            
            decimal valorFuturo = parametros.ValorCredito * (decimal)Math.Pow((double)(1 + taxaJuros), parametros.QuantidadeParcelas);
             


            //decimal valorTotal = parametros.ValorCredito * (decimal)Math.Pow((double)(1 + taxaJuros), parametros.QuantidadeParcelas);
            decimal jurosTotal = valorFuturo - parametros.ValorCredito;


            retorno.statusCredito = "APROVADO";
            retorno.valorTotalComJuros = valorFuturo;
            retorno.valorDoJuros = jurosTotal;

            return retorno;

        }
    }
}

