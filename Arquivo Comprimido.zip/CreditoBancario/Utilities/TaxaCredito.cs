﻿using System;
namespace CreditoBancario.Utilities
{
	public class TaxaCredito
	{
        public const decimal CREDITO_DIRETO = 2;
        public const decimal CREDITO_CONSIGNADO = 1;
        public const decimal CREDITO_PESSOA_JURIDICA = 5;
        public const decimal CREDITO_PESSOA_FISICA = 3;
        public const decimal CREDITO_IMOBILIARIO = 9;

    }
}

