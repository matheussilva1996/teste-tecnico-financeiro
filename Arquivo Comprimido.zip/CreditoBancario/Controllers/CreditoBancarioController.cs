﻿using System;
using CreditoBancario.Request;
using CreditoBancario.Response;
using CreditoBancario.Service;
using Microsoft.AspNetCore.Mvc;

namespace CreditoBancario.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CreditoBancarioController : ControllerBase
    {
        [HttpPost("AnaliseCredito")]
        public async Task<ActionResult<RetornoStatusCredito>> AnaliseCredito(ParametrosCreditoRequest parametrosCreditoRequest)
        {
            RetornoStatusCredito retorno = new RetornoStatusCredito();
            retorno = CalculoEmprestimo.CalculoEmprestimoJuros(parametrosCreditoRequest);
            return retorno;
        }
    }
}

